package com;

public class School {
	
	private String schoolName;
	private int standard;
	private Address addr;
	public School(String schoolName, int standard, Address addr) {
		super();
		this.schoolName = schoolName;
		this.standard = standard;
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "School [schoolName=" + schoolName + ", standard=" + standard + ", addr=" + addr + "]";
	}
	
	
	

}
