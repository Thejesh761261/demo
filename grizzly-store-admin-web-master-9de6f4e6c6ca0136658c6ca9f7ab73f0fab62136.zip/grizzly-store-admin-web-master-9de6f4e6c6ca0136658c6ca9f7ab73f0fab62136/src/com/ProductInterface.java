package com;

public interface ProductInterface {

	public boolean insert(Product p);
}
