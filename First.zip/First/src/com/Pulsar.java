package com;

public class Pulsar  implements BajajBike {

	public void display()
	{
		System.out.println("This is Pulsar bike");
	}
}
