package serv;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import serv.bean.UpdateBean;

public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("Login first");
		RequestDispatcher dt=request.getRequestDispatcher("login.html");
		dt.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("s1");
		int stock=Integer.parseInt(request.getParameter("s2"));
		UpdateBean eb1=new UpdateBean();
		eb1.setStock(stock);
		eb1.setId(id);
		boolean status=eb1.verify();
		if(status==true)
		{
			PrintWriter out1=response.getWriter();
			out1.println("<h1>Updation success</h1>");
			RequestDispatcher dt=request.getRequestDispatcher("inventory.jsp");
			dt.include(request, response);
		}
		else
		{
			PrintWriter out1=response.getWriter();
			out1.println("<h1>Updation failed. Please try again</h1>");
			RequestDispatcher dt=request.getRequestDispatcher("inventory.jsp");
			dt.include(request, response);
		}
	}

}
