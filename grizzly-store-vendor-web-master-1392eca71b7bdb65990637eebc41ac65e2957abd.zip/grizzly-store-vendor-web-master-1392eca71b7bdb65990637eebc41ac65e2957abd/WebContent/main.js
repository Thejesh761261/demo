function s1(initVal){
    var stock=prompt("Enter In stock value: ","");
    var a=document.getElementById(initVal).textContent ;
    document.getElementById(initVal).innerHTML=eval(stock)+eval(a);
	
}