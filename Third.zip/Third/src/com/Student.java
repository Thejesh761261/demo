package com;

public class Student {
	private int rollNo;
	private String name;
	private int age;
	private School school;
	public Student(int rollNo, String name, int age,School school) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
		this.school=school;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", age=" + age + ", school=" + school + "]";
	}
	
}
