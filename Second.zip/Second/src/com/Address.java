package com;

public class Address {
	private String state;
	private int pin;
	private String city;
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		System.out.println("State: "+state);
		System.out.println("Pin: "+pin);
		System.out.println("City: "+city);
		return "";
	}
	

}
