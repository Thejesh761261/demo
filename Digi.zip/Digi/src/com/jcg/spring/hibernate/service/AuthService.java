
package com.jcg.spring.hibernate.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional; 

import com.jcg.spring.hibernate.pojo.*;

public class AuthService {

	private HibernateTemplate hibernateTemplate;
	private static Logger log = Logger.getLogger(AuthService.class);

	private AuthService() {
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	public String findUser(String uname, String upwd, String type) {
		log.info("Checking the user in the database");
		boolean isValidUser = false;
		String name = "";
		String sqlQuery = "from User u where u.userid=? and u.password=? and u.type=?";
		System.out.println(
				"In the authentication service...user entered data " + uname + " pwd " + upwd + " " + "type " + type);
		try {
			List<User> userObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd, type);
			if (userObj != null) {
				System.out.println("userObject is not null... ");
				for (User obj : userObj) {
					System.out
							.println("Id " + obj.getUserid() + " Name " + obj.getFn() + " Editor " + obj.getPassword());
					name = obj.getFn();
				}

			}

			if (userObj != null && userObj.size() > 0) {
				// log.info("Id= " + userObj.get(0)).getId() + ", Name= " +
				// userObj.get(0).getName() + ", Password= " +
				// userObj.get(0).getPassword());
				isValidUser = true;
			}
		} catch (Exception e) {
			isValidUser = false;
			log.error("An error occurred while fetching the user details from the database", e);
		}
		System.out.println(name);
		if (isValidUser == true) {
			return name;
		} else {
			return "null";
		}
		// return isValidUser;
	}

	public boolean insertUser(User u) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			System.out.println(u.getEmail());

			hibernateTemplate.save(u);


			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}

	public boolean insertCourse(Course c) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			System.out.println(c.getTime());

			hibernateTemplate.save(c);

			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}
   
	public boolean delCourse(String c) {
		log.info("Checking the user in the database");
		boolean isValid = true;
		try {
			
				hibernateTemplate.bulkUpdate("DELETE FROM Course where code='"+c+"'");
		
		//	Session session = sessionFactory.getCurrentSession();

			
			return isValid;
		}

		catch (Exception e) {
			System.out.println("In the catch block of delete..."+e);
			isValid = false;
			e.printStackTrace();
			log.error("An error occurred while fetching the user details from the database", e);
		}

		return isValid;
	}
	
	
	
	
	
	
	public boolean modifyCourse(String c,String r) {
		log.info("Modify course in the database");
		boolean isValid = true;
		
		
		try {
				hibernateTemplate.bulkUpdate("UPDATE Course SET ref='"+r+"' where code='"+c+"'");
				return isValid;
		}

		catch (Exception e) {
			System.out.println("In the catch block of modify..."+e);
			isValid = false;
			e.printStackTrace();
			log.error("An error occurred while fetching the user details from the database", e);
		}

		return isValid;
	}
	
	
	
    public String findUsss(String uname, String upwd,String type)
    
    {
    	
    	log.info("Checking the user in the database");
		boolean isValidUser = false;
		String name = "";
		String sqlQuery = "from User u where u.userid=? and u.password=? and u.type=?";
		System.out.println(
				"In the authentication service...user entered data " + uname + " pwd " + upwd + " " + "type " + type);
		try {
			List<User> userObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd, type);
			if (userObj != null) {
				System.out.println("userObject is not null... ");
				for (User obj : userObj) {
					System.out
							.println("Id " + obj.getUserid() + " Name " + obj.getFn() + " Editor " + obj.getPassword());
					name = obj.getFn();
				}

			}

			if (userObj != null && userObj.size() > 0) {
				// log.info("Id= " + userObj.get(0)).getId() + ", Name= " +
				// userObj.get(0).getName() + ", Password= " +
				// userObj.get(0).getPassword());
				isValidUser = true;
			}
		} catch (Exception e) {
			isValidUser = false;
			log.error("An error occurred while fetching the user details from the database", e);
		}
		System.out.println(name);
		if (isValidUser == true) {
			return name;
		} else {
			return "null";
		}
		// return isValidUser;
    }
	
	 public List fetchCourse()
	    {
	    	log.info("Checking the user in the database");
	    	 List<Course> userObj=null;
	        
	         try {
	        	 
	         	
	        	String sqlQuery = "from Course";        	
	        	 
	         	 userObj = (List<Course>) hibernateTemplate.find(sqlQuery);
	        	 
	         	System.out.println("After select query from session..");
	         	
	            if(userObj != null)
	            {
	            	System.out.println("userObject is not null... ");
	                for (Course obj : userObj)
	                {
	                  
	                    return userObj;
	                }

	            }
	        } 
	         catch(Exception e) 
	         {
	         
	            log.error("An error occurred while fetching the user details from the database", e); 
	            System.out.println(e);
	      
	        }
	         return userObj;
	   
	    
	  

	    }


	
}
