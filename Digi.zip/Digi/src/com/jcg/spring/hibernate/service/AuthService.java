
package com.jcg.spring.hibernate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.jcg.spring.hibernate.pojo.*;

public class AuthService {

	private HibernateTemplate hibernateTemplate;
	private static Logger log = Logger.getLogger(AuthService.class);

	private AuthService() {
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	/*@SuppressWarnings({ "unchecked", "deprecation" })
	public String findUser(String uname, String upwd, String type) {
		log.info("Checking the user in the database");
		boolean isValidUser = false;
		String name = "";
		String sqlQuery = "from User u where u.userid=? and u.password=? and u.type=?";
		System.out.println(
				"In the authentication service...user entered data " + uname + " pwd " + upwd + " " + "type " + type);
		try {
			List<User> userObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd, type);
			if (userObj != null) {
				System.out.println("userObject is not null... ");
				for (User obj : userObj) {
					System.out
							.println("Id " + obj.getUserid() + " Name " + obj.getFn() + " Editor " + obj.getPassword());
					name = obj.getFn();
				}

			}

			if (userObj != null && userObj.size() > 0) {
				// log.info("Id= " + userObj.get(0)).getId() + ", Name= " +
				// userObj.get(0).getName() + ", Password= " +
				// userObj.get(0).getPassword());
				isValidUser = true;
			}
		} catch (Exception e) {
			isValidUser = false;
			log.error("An error occurred while fetching the user details from the database", e);
		}
		System.out.println(name);
		if (isValidUser == true) {
			return name;
		} else {
			return "null";
		}
		// return isValidUser;
	}*/

	public boolean insertUser(User u) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			System.out.println(u.getEmail());

			hibernateTemplate.save(u);


			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}

	public boolean insertCourse(Course c) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			System.out.println(c.getTime());

			hibernateTemplate.save(c);

			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}
	
	public boolean insertQuestion(QuesAdding c) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;
			hibernateTemplate.save(c);

			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}
   
	public boolean delCourse(String c) {
		log.info("Checking the user in the database");
		boolean isValid = true;
		try {
			
				hibernateTemplate.bulkUpdate("DELETE FROM Course where code='"+c+"'");
		
		//	Session session = sessionFactory.getCurrentSession();

			
			return isValid;
		}

		catch (Exception e) {
			System.out.println("In the catch block of delete..."+e);
			isValid = false;
			e.printStackTrace();
			log.error("An error occurred while fetching the user details from the database", e);
		}

		return isValid;
	}
	
	
	
	
	
	
	public boolean modifyCourse(String c,String r) {
		log.info("Modify course in the database");
		boolean isValid = true;
		
		
		try {
				hibernateTemplate.bulkUpdate("UPDATE Course SET ref='"+r+"' where code='"+c+"'");
				return isValid;
		}

		catch (Exception e) {
			System.out.println("In the catch block of modify..."+e);
			isValid = false;
			e.printStackTrace();
			log.error("An error occurred while fetching the user details from the database", e);
		}

		return isValid;
	}
	
	
	
    public String findUser(String uname, String upwd,String type)
    
    {
    	
    	log.info("Checking the user in the database");
		boolean isValidUser = false;
		String name = "";
		String sqlQuery = "from User u where u.userid=? and u.password=? and u.type=?";
		System.out.println(
				"In the authentication service...user entered data " + uname + " pwd " + upwd + " " + "type " + type);
		try {
			List<User> userObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd, type);
			if (userObj != null) {
				System.out.println("userObject is not null... ");
				for (User obj : userObj) {
					System.out
							.println("Id " + obj.getUserid() + " Name " + obj.getFn() + " Editor " + obj.getPassword());
					name = obj.getFn();
				}

			}

			if (userObj != null && userObj.size() > 0) {
				// log.info("Id= " + userObj.get(0)).getId() + ", Name= " +
				// userObj.get(0).getName() + ", Password= " +
				// userObj.get(0).getPassword());
				isValidUser = true;
			}
		} catch (Exception e) {
			isValidUser = false;
			log.error("An error occurred while fetching the user details from the database", e);
		}
		System.out.println(name);
		if (isValidUser == true) {
			return name;
		} else {
			return "null";
		}
		// return isValidUser;
    }
	
	 public List fetchCourse()
	    {
	    	log.info("Checking the user in the database");
	    	 List<Course> userObj=null;
	        
	         try {
	        	 
	         	
	        	String sqlQuery = "from Course";        	
	        	 
	         	 userObj = (List<Course>) hibernateTemplate.find(sqlQuery);
	        	 
	         	System.out.println("After select query from session..");
	         	
	            if(userObj != null)
	            {
	            	System.out.println("userObject is not null... ");
	                for (Course obj : userObj)
	                {
	                  
	                    return userObj;
	                }

	            }
	        } 
	         catch(Exception e) 
	         {
	         
	            log.error("An error occurred while fetching the user details from the database", e); 
	            System.out.println(e);
	      
	        }
	         return userObj;
	   
	    
	  

	    }
	 
	 
	 public List fetchQuestions(String code)
	    {
		 Session session = hibernateTemplate.getSessionFactory().openSession();
         System.out.println("Current session "+session);
         String sqlQuery1 = "select * from question where course_id='"+code+"'";
        
          session.beginTransaction();

         SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
        
         insertQuery.addEntity(QuesAdding.class);
         List<QuesAdding> results = insertQuery.list();
	        return results;
	   
	    }
	 
	 public List<Result> fetchCourses(String id) {
         
         Session session = hibernateTemplate.getSessionFactory().openSession();
         System.out.println("Current session "+session);
         
         String sqlQuery1 = "select * from courses";
         //Exam e1=new Exam();
          session.beginTransaction();

         SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
         //insertQuery.setParameter(0, e1.getEid());
         insertQuery.addEntity(Course.class);
         List<Course> results = insertQuery.list();
         HashMap <String, String> map = new HashMap<String,String>();
         
         System.out.println("auth"+results);
         for (Course obj : results)
         {
           map.put(obj.getCode(), obj.getSkill());
             //System.out.println(obj.getSkill());
         }
         String res = "select * from result where eid='"+id+"'";
         System.out.println("query :"+res);
         SQLQuery resultQuery = session.createSQLQuery(res);
         //insertQuery.setParameter(0, e1.getEid());
         resultQuery.addEntity(Exam.class);
         
         List<Exam> examList = resultQuery.list();
         List<Result> resultList=new ArrayList<Result>();
         for (Exam obj : examList)
         {
        	 Result res1=new Result();
        	 res1.setCode(obj.getCode());
        	 res1.setDate(obj.getDate());
        	 res1.setEid(obj.getEid());
        	 res1.setSkill(map.get(obj.getCode()));
 
        	 res1.setMarks(obj.getMarks());
        	 resultList.add(res1);
             System.out.println(obj.getDate());
             System.out.println(obj.getMarks());
         }
         return resultList;
  }

	 
	 public boolean insertResult(Exam c) {
			try {

				System.out.println("Before Entering Data");
				boolean isValidUser = true;

				System.out.println(c.getEid());

				hibernateTemplate.save(c);

				System.out.println("After Entering Data");

				return isValidUser;
			} catch (Exception ex) {
				System.out.println(ex);
				ex.printStackTrace();

			}
			return false;
		}

public int fetchReport(String code) {
         
         Session session = hibernateTemplate.getSessionFactory().openSession();
         System.out.println("Current session "+session);
         
         String sqlQuery1 = "select count(distinct eid) from Exam where code='"+code+"'";
         int results = ((Long)session.createQuery(sqlQuery1).uniqueResult()).intValue();
         //Exam e1=new Exam();
          session.beginTransaction();

         SQLQuery resultQuery = session.createSQLQuery(sqlQuery1);
         //resultQuery.addEntity(Exam.class);
        // int results = executeUpdate(resultQuery);
         System.out.println("count"+results);
         return results;
  }
 public void logout()
 {
	 Session session = hibernateTemplate.getSessionFactory().openSession();
	 session.close();
	 
 }
	 
	 
	
}
