package com;

public class Address {
	private String state;
	private int pin;
	private String city;
	
	public Address(String state, int pin, String city) {
		super();
		this.state = state;
		this.pin = pin;
		this.city = city;
	}

	@Override
	public String toString() {
		System.out.println("State: "+state);
		System.out.println("Pin: "+pin);
		System.out.println("City: "+city);
		return "";
	}
	

}
