package com.jcg.spring.hibernate.ctrl;
 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.jcg.spring.hibernate.pojo.*;
import com.jcg.spring.hibernate.service.AuthService;
 
@Controller

public class ApplicationCtrl {
	
	
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
 
    private static Logger log = Logger.getLogger(ApplicationCtrl.class);
    
    
    //HttpSession session=request.getSession();
   
    @RequestMapping("/")  
    public String display()  
    {  
        return "index";  
    }     
	
	@RequestMapping("/empLogin")  
    public String login()  
    {  
		//HttpSession session=request.getSession();
        return "empLogin";  
    } 
	
	@RequestMapping("/adminLogin")  
    public String adminLogin()  
    {  
        return "adminLogin";  
    } 
	
	@RequestMapping("/empRegister")  
    public String empRegister()  
    {  
        return "empRegister";  
    } 
	
	
	@RequestMapping("/adminRegister")  
    public String register1()  
    {  
        return "adminRegister";  
    } 

	 @RequestMapping("/admin")  
	  public String admin()  
	  {  
	      return "adminLogin";  
	  } 
	
	@RequestMapping("/addCourse")  
    public ModelAndView addCourse(ModelAndView model,HttpServletRequest request)  
    {  
		if(request.getSession().getAttribute("user")==null)
        {
               return new ModelAndView("redirect:/");
        }
		else{
		model.setViewName("add");
        return model;
		}  
    } 
	
	
	@RequestMapping("/modify")  
    public ModelAndView modify(ModelAndView model,HttpServletRequest request)  
    {  
		
		if(request.getSession().getAttribute("user")==null)
        {
               return new ModelAndView("redirect:/");
        }
		else{
		model.setViewName("modify");
        return model;
		}
    }
	
	@RequestMapping("/addQuestion")  
    public ModelAndView addQuestion(ModelAndView model,HttpServletRequest request,@RequestParam("code")String code)  
    {  
		
		if(request.getSession().getAttribute("user")==null)
        {
               return new ModelAndView("redirect:/");
        }
		else{
		model.addObject("cid",code);	
		model.setViewName("addQuestion");
        return model;
		}
    }
	
	
	@RequestMapping(value = "/quiz1", method = RequestMethod.GET)
	public ModelAndView quiz1(ModelAndView model,HttpServletRequest request,@RequestParam("code")String code) {
		
        
        
        
        
        System.out.println("In the controller..");
        
            List<QuesAdding> questions =  authenticateService.fetchQuestions(code);
        	model.addObject("code",code);
        	model.addObject("question",questions);
           model.setViewName("quiz");
           return model;
            
       
	}
	 
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView loadApp(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		
			session.setAttribute("user", null);
			session.invalidate();
		
		
		authenticateService.logout();

		return new ModelAndView("index");
	}
	@RequestMapping("/summary")  
    public ModelAndView showSummary(HttpServletRequest request,@RequestParam("code")String code,@RequestParam("score")String score,@RequestParam("stop")String date)  
    {  
		
		Exam u=new Exam();
		HttpSession session=request.getSession();
		DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date d=new Date();
	    sdf.setTimeZone(TimeZone.getTimeZone("IST"));
	    String dat=(sdf.format(d)).toString();
		String id=(session.getAttribute("id")).toString();
    	u.setCode(code);
    	u.setEid(id);
    	u.setMarks(score);
    	u.setDate(dat);
    	
        String msg = "";
        boolean isValid = authenticateService.insertResult(u);
        log.info("Is entry valid?= " + isValid);
        
        System.out.println("In the controller..");
        ModelAndView model=new ModelAndView("res");
        if(isValid) {
        	
        		msg = "Marks Added successfully... !";
        		model.addObject("s1",msg);
        		model.addObject("score",score);
                //List<Course> lstProduct =  authenticateService.fetchCourse();
                //model.addObject("result",lstProduct);
        		return model;
        }
        else {
        	
    		msg = "Invalid credentials ... please try again";
    		model.addObject("s2",msg);
            //List<Course> lstProduct =  authenticateService.fetchCourse();
            //model.addObject("result",lstProduct);
    		return model;
    }
    }
   
    
        // Checks if the user credentials are valid or not.
        @RequestMapping(value = "/insert", method = RequestMethod.POST)
        public ModelAndView insertUsr(@RequestParam("fn")String fn, 
        		@RequestParam("ln")String ln, 
        		@RequestParam("age")int age, 
        		@RequestParam("gender")String gender, 
        		@RequestParam("contact")double contact, 
        		@RequestParam("userid")String userid, 
        		@RequestParam("mail")String mail,
        		@RequestParam("password")String password,
        		@RequestParam("type")String type) {
        	
        	
        	System.out.println(age);
        	User r=new User();
        	r.setFn(fn);
        	r.setAge(age);
        	r.setContact(contact);
        	r.setEmail(mail);
        	r.setUserid(userid);
        	r.setGender(gender);
        	r.setLn(ln);
        	r.setPassword(password);
        	r.setType(type);
            String msg = "";
            boolean isValid = authenticateService.insertUser(r);
            log.info("Is user valid?= " + isValid);
            
            System.out.println("In the controller..");
            if(isValid) {
            
            	if(r.getType().equals("U"))
            	{
            		msg = "Inserted successfully... please Login! ";
            		return new ModelAndView("empLogin", "output", msg);
            	}
            	else
            	{
            		msg = "Inserted successfully .. Please adminLogin! ";
            		return new ModelAndView("adminLogin", "output", msg);
            	}
                
            } 
            else {
            	if(r.getType().equals("U"))
            	{
            		msg = "Invalid credentials ... please register again";
            		return new ModelAndView("empRegister", "output", msg);
            	}
            	else{
            		msg = "Invalid credentials ... please register again";
            		return new ModelAndView("adminRegister", "output", msg);
            	}
            }
            
     
          
        }
        
     // Checks if the add course are valid or not.
        @RequestMapping(value = "/insertCourse", method = RequestMethod.POST)
        public ModelAndView insertCoure( 
        		@RequestParam("code")String code, 
        		@RequestParam("description")String description, 
        		@RequestParam("skill")String skill, 
        		@RequestParam("added")String added, 
        		@RequestParam("ref")String ref ) {
        	
        	
        	System.out.println(skill);
        	Course u=new Course();
        	Date dat=new Date();
        	SimpleDateFormat d1=new SimpleDateFormat("dd-MM-yyyy");
        	String newDate=(d1.format(dat)).toString();
        	System.out.println(newDate);
        	 String strDateFormat = "hh:mm:ss"; //Date format is Specified
       	  SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); //Date format string is passed as an argument to the Date format object
       	  String tim=(objSDF.format(dat)).toString(); //Date formatting is applied to the current date
        	u.setCode(code);
        	u.setDescription(description);
        	u.setSkill(skill);
        	u.setDate(newDate);
        	u.setTime(tim);
        	u.setAdded(added);
        	u.setRef(ref);
        	
            String msg = "";
            boolean isValid = authenticateService.insertCourse(u);
            log.info("Is entry valid?= " + isValid);
            
            System.out.println("In the controller..");
            ModelAndView model=new ModelAndView("adminHome");
            if(isValid) {
            	
            		msg = "Course Added successfully... !";
            		model.addObject("s1",msg);
                    List<Course> lstProduct =  authenticateService.fetchCourse();
                    model.addObject("result",lstProduct);
            		return model;
            } 
            else {
            	
            		msg = "Invalid credentials ... please try again";
            		model.addObject("s2",msg);
                    List<Course> lstProduct =  authenticateService.fetchCourse();
                    model.addObject("result",lstProduct);
            		return model;
            }
 
        }
        
        
        
        @RequestMapping(value = "/insertQuestion", method = RequestMethod.POST)
        public ModelAndView insertQuestion( 
        		@RequestParam("cId")String cId, 
        		@RequestParam("question")String question, 
        		@RequestParam("a")String a, 
        		@RequestParam("b")String b, 
        		@RequestParam("c")String c,
        		@RequestParam("d")String d,
        		@RequestParam("answer")String answer,
        		@RequestParam("mark")int mark) {
        	
        	
        	System.out.println(cId);
        	QuesAdding u=new QuesAdding();
        	u.setcId(cId);
        	u.setQuestion(question);
        	u.setA(a);
        	u.setB(b);
        	u.setC(c);
        	u.setD(d);
        	u.setMark(mark);
        	u.setAnswer(answer);
        	
        	
            String msg = "";
            boolean isValid = authenticateService.insertQuestion(u);
            log.info("Is entry valid?= " + isValid);
            
            System.out.println("In the controller..");
            ModelAndView model=new ModelAndView("adminHome");
            if(isValid) {
            	
            		msg = "Question insertion successfully... !";
            		model.addObject("s1",msg);
                    List<Course> lstProduct =  authenticateService.fetchCourse();
                    model.addObject("result",lstProduct);
            		return model;
            } 
            else {
            	
            		msg = "Invalid credentials ... please try again";
            		model.addObject("s2",msg);
                    List<Course> lstProduct =  authenticateService.fetchCourse();
                    model.addObject("result",lstProduct);
            		return model;
            }
 
        }
        
        @RequestMapping(value = "/deleteCourse", method = RequestMethod.GET)
        public ModelAndView validateUsr(HttpServletRequest request,@RequestParam("code")String code) {
        	

        	if(request.getSession().getAttribute("user")==null)
            {
                   return new ModelAndView("redirect:/");
            }
        	
        	else{
            String msg = "";
            //Course u=new Course();
           // u.setCode(code);
            ModelAndView model=new ModelAndView("adminHome");
            boolean isValid = authenticateService.delCourse(code);
            log.info("Is user valid?= " + isValid);
     
            if(isValid == true) {
                msg = "Deletion success!";
                model.addObject("s2",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;

                
            } else {
                msg = "Unsuccessful";
                model.addObject("s2",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;
            }
        	}
     
        }
        
        @RequestMapping(value = "/modifyCourse", method = RequestMethod.POST)
        public ModelAndView validateUsr(HttpServletRequest request,@RequestParam("code")String code,@RequestParam("ref")String ref) {
        	
        	if(request.getSession().getAttribute("user")==null)
            {
                   return new ModelAndView("redirect:/");
            }

        	else{
            String msg = "";
            //Course u=new Course();
           // u.setCode(code);
           boolean isValid = authenticateService.modifyCourse(code,ref);
            log.info("Is user valid?= " + isValid);
            ModelAndView model=new ModelAndView("adminHome");
     
            if(isValid == true) {
                msg = "Updation success!";
                model.addObject("s1",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;
                
            } else {
                msg = "Unsuccessful";
                model.addObject("s1",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;
            }
        	}
     
        }
        
        
        
        @RequestMapping(value = "/empValidater", method = RequestMethod.POST)
        public ModelAndView validateUsr(@RequestParam("username")String username, @RequestParam("password")String password, @RequestParam("type")String type,HttpServletRequest request) 
        {
            String msg = "";
            HttpSession session=request.getSession();
            session.setAttribute("id", username);
            
             String isValid = authenticateService.findUser(username, password,type);
         
            
            log.info("Is user valid?= " + isValid);
            
            System.out.println("In the controller..");
            if(isValid!="null") {
                msg = "Welcome " + isValid + "!";
                if (session.getAttribute("user") == null)
                {
        			session.setAttribute("user", msg);
                }
                List<Course> lstProduct =  authenticateService.fetchCourse();
            	
                return new ModelAndView("empHome", "result1",lstProduct );
                
            } else {
                msg = "Invalid credentials";
                return new ModelAndView("empLogin","output",msg);
            }
           
        }
        
        
        @RequestMapping(value = "/adminValidater", method = RequestMethod.POST)
        public ModelAndView validateUser(@RequestParam("username")String username, @RequestParam("password")String password, @RequestParam("type")String type,HttpServletRequest request) 
        {
            String msg = "";
            HttpSession session=request.getSession();
            session.setAttribute("id", username);
             String isValid = authenticateService.findUser(username, password,type);
            log.info("Is user valid?= " + isValid);
            
            System.out.println("In the controller..");
            if(isValid!="null") {
                msg = "Welcome " + isValid + "!";
                if (session.getAttribute("user") == null)
                {
        			session.setAttribute("user", msg);
                }
                List<Course> lstProduct =  authenticateService.fetchCourse();
            	
            	
                return new ModelAndView("adminHome", "result",lstProduct );
                
            } else {
                msg = "Invalid credentials";
                return new ModelAndView("adminLogin","output",msg);
            }
           
        }
        
        @RequestMapping(value = "/quiz", method = RequestMethod.GET)
        public ModelAndView insertCoure( 
        		@RequestParam("code")String code, 
        		@RequestParam("eid")String eid, 
        		@RequestParam("marks")String marks ) {
        	
        	
        	System.out.println(code);
        	Exam u=new Exam();
        	Date dat=new Date();
        	SimpleDateFormat d1=new SimpleDateFormat("dd-MM-yyyy a");
        	String newDate=(d1.format(dat)).toString();
        	System.out.println(newDate);
        	u.setCode(code);
        	u.setEid(eid);
        	u.setMarks(marks);
        	u.setDate(newDate);
        	
            String msg = "";
            boolean isValid = authenticateService.insertResult(u);
            log.info("Is entry valid?= " + isValid);
            
            System.out.println("In the controller..");
            ModelAndView model=new ModelAndView("res");
            if(isValid) {
            	
            		msg = "Marks Added successfully... !";
            		model.addObject("s1",msg);
                    //List<Course> lstProduct =  authenticateService.fetchCourse();
                    //model.addObject("result",lstProduct);
            		return model;
            } 
            else {
            	
            		msg = "Invalid credentials ... please try again";
            		model.addObject("s2",msg);
                    //List<Course> lstProduct =  authenticateService.fetchCourse();
                    //model.addObject("result",lstProduct);
            		return model;
            }
 
        }

        
        @RequestMapping(value = "/completed", method = RequestMethod.GET)
        public ModelAndView back(@RequestParam("c")String c,HttpServletRequest request) {
        	
        	if(request.getSession().getAttribute("user")==null)
            {
                   return new ModelAndView("redirect:/");
            }
        	else{
            ModelAndView model=new ModelAndView("completed");
            System.out.println("in back Controller");
                List<Result> courses =  authenticateService.fetchCourses(c);
                model.addObject("result1",courses);
        		return model;
        	}

        }
       
        @RequestMapping("/back")  
        public ModelAndView back(HttpServletRequest request)
        {  
        	if(request.getSession().getAttribute("user")==null)
            {
                   return new ModelAndView("redirect:/");
            }
        	else{
        	ModelAndView model=new ModelAndView("empHome");
       
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result1",lstProduct);
        		return model;  
        	}
        }
        
        @RequestMapping(value="/report",method=RequestMethod.GET)  
        public ModelAndView report(@RequestParam("code")String code,HttpServletRequest request) {
        	
        	if(request.getSession().getAttribute("user")==null)
            {
                   return new ModelAndView("redirect:/");
            }
        	else
        	{
            ModelAndView model=new ModelAndView("report");
            System.out.println("in report Controller");
                int courseReport =  authenticateService.fetchReport(code);
                model.addObject("result",courseReport);
        		return model;
        	}
        }
       
        
     
}