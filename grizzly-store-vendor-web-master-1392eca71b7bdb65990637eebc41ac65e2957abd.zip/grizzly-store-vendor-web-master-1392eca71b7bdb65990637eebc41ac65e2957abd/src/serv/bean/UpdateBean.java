package serv.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateBean {

	private int stock;
	private String id;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	public boolean verify() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "tiger");
			Statement stmt = con.createStatement();
			if(stmt.executeUpdate("update INVENTORY set INSTOCK="+stock+" where PID='"+id+"'")==1)
			{
				return true;
			}

			stmt.close();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}
}
