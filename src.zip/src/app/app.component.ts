import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  public value=true;


  getValue(){
    return this.value;
  }

  onClick(){
    this.value=!this.value;
  }
  title = 'Dem';
}
