package com;

public class Platina  implements BajajBike{

	public void display()
	{
		System.out.println("This is Platina bike");
	}
}
