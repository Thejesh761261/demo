import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hem',
  templateUrl: './hem.component.html',
  styleUrls: ['./hem.component.css']
})
export class HemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
