package com.jcg.spring.hibernate.ctrl;
 
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.jcg.spring.hibernate.pojo.*;
import com.jcg.spring.hibernate.service.AuthService;
 
@Controller

public class ApplicationCtrl {
	
	
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
 
    private static Logger log = Logger.getLogger(ApplicationCtrl.class);
    
    
    //HttpSession session=request.getSession();
   
    @RequestMapping("/")  
    public String display()  
    {  
        return "index";  
    }     
	
	@RequestMapping("/login")  
    public String login()  
    {  
		//HttpSession session=request.getSession();
        return "login";  
    } 
	
	@RequestMapping("/login1")  
    public String login1()  
    {  
        return "login1";  
    } 
	
	@RequestMapping("/register")  
    public String register()  
    {  
        return "register";  
    } 
	
	
	@RequestMapping("/register1")  
    public String register1()  
    {  
        return "register1";  
    } 
	
	@RequestMapping("/addCourse")  
    public String addCourse()  
    {  
        return "add";  
    } 
	
	
	@RequestMapping("/modify")  
    public String modify()  
    {  
        return "modify";  
    }
	
	 
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView loadApp(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		
		authenticateService.logout();

		return new ModelAndView("index");
	}
 
   
    
        // Checks if the user credentials are valid or not.
        @RequestMapping(value = "/insert", method = RequestMethod.POST)
        public ModelAndView insertUsr(@RequestParam("fn")String fn, 
        		@RequestParam("ln")String ln, 
        		@RequestParam("age")int age, 
        		@RequestParam("gender")String gender, 
        		@RequestParam("contact")double contact, 
        		@RequestParam("userid")String userid, 
        		@RequestParam("mail")String mail,
        		@RequestParam("password")String password,
        		@RequestParam("type")String type) {
        	
        	
        	System.out.println(age);
        	User r=new User();
        	r.setFn(fn);
        	r.setAge(age);
        	r.setContact(contact);
        	r.setEmail(mail);
        	r.setUserid(userid);
        	r.setGender(gender);
        	r.setLn(ln);
        	r.setPassword(password);
        	r.setType(type);
            String msg = "";
            boolean isValid = authenticateService.insertUser(r);
            log.info("Is user valid?= " + isValid);
            
            System.out.println("In the controller..");
            if(isValid) {
            
            	if(r.getType().equals("U"))
            	{
            		msg = "Inserted successfully... please Login! ";
            		return new ModelAndView("login", "output", msg);
            	}
            	else
            	{
            		msg = "Inserted successfully .. Please Login1! ";
            		return new ModelAndView("login1", "output", msg);
            	}
                
            } 
            else {
            	if(r.getType().equals("U"))
            	{
            		msg = "Invalid credentials ... please register again";
            		return new ModelAndView("register", "output", msg);
            	}
            	else{
            		msg = "Invalid credentials ... please register again";
            		return new ModelAndView("register1", "output", msg);
            	}
            }
            
     
          
        }
        
     // Checks if the add course are valid or not.
        @RequestMapping(value = "/insert1", method = RequestMethod.POST)
        public ModelAndView insertCoure( 
        		@RequestParam("code")String code, 
        		@RequestParam("description")String description, 
        		@RequestParam("skill")String skill, 
        		@RequestParam("added")String added, 
        		@RequestParam("ref")String ref ) {
        	
        	
        	System.out.println(skill);
        	Course u=new Course();
        	Date dat=new Date();
        	SimpleDateFormat d1=new SimpleDateFormat("dd-MM-yyyy");
        	String newDate=(d1.format(dat)).toString();
        	System.out.println(newDate);
        	 String strDateFormat = "hh:mm:ss"; //Date format is Specified
       	  SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); //Date format string is passed as an argument to the Date format object
       	  String tim=(objSDF.format(dat)).toString(); //Date formatting is applied to the current date
        	u.setCode(code);
        	u.setDescription(description);
        	u.setSkill(skill);
        	u.setDate(newDate);
        	u.setTime(tim);
        	u.setAdded(added);
        	u.setRef(ref);
        	
            String msg = "";
            boolean isValid = authenticateService.insertCourse(u);
            log.info("Is entry valid?= " + isValid);
            
            System.out.println("In the controller..");
            ModelAndView model=new ModelAndView("result1");
            if(isValid) {
            	
            		msg = "Course Added successfully... !";
            		model.addObject("s1",msg);
                    List<Course> lstProduct =  authenticateService.fetchCourse();
                    model.addObject("result",lstProduct);
            		return model;
            } 
            else {
            	
            		msg = "Invalid credentials ... please try again";
            		model.addObject("s2",msg);
                    List<Course> lstProduct =  authenticateService.fetchCourse();
                    model.addObject("result",lstProduct);
            		return model;
            }
 
        }
        
        @RequestMapping(value = "/deleteCourse", method = RequestMethod.GET)
        public ModelAndView validateUsr(@RequestParam("code")String code) {
            String msg = "";
            //Course u=new Course();
           // u.setCode(code);
            ModelAndView model=new ModelAndView("result1");
            boolean isValid = authenticateService.delCourse(code);
            log.info("Is user valid?= " + isValid);
     
            if(isValid == true) {
                msg = "Deletion success!";
                model.addObject("s2",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;

                
            } else {
                msg = "Unsuccessful";
                model.addObject("s2",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;
            }
     
        }
        
        @RequestMapping(value = "/modifyCourse", method = RequestMethod.POST)
        public ModelAndView validateUsr(@RequestParam("code")String code,@RequestParam("ref")String ref) {
            String msg = "";
            //Course u=new Course();
           // u.setCode(code);
           boolean isValid = authenticateService.modifyCourse(code,ref);
            log.info("Is user valid?= " + isValid);
            ModelAndView model=new ModelAndView("result1");
     
            if(isValid == true) {
                msg = "Updation success!";
                model.addObject("s1",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;
                
            } else {
                msg = "Unsuccessful";
                model.addObject("s1",msg);
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result",lstProduct);
        		return model;
            }
     
        }
        
        
        
        @RequestMapping(value = "/validater", method = RequestMethod.POST)
        public ModelAndView validateUssr(@RequestParam("username")String username, @RequestParam("password")String password, @RequestParam("type")String type,HttpServletRequest request) 
        {
            String msg = "";
            HttpSession session=request.getSession();
            session.setAttribute("id", username);
            
             String isValid = authenticateService.findUsss(username, password,type);
         
            
            log.info("Is user valid?= " + isValid);
            
            System.out.println("In the controller..");
            if(isValid!="null") {
                msg = "Welcome " + isValid + "!";
                if (session.getAttribute("user") == null)
                {
        			session.setAttribute("user", msg);
                }
                List<Course> lstProduct =  authenticateService.fetchCourse();
            	
                return new ModelAndView("result", "result1",lstProduct );
                
            } else {
                msg = "Invalid credentials";
                return new ModelAndView("login","output",msg);
            }
           
        }
        
        
        @RequestMapping(value = "/validater1", method = RequestMethod.POST)
        public ModelAndView validateUs(@RequestParam("username")String username, @RequestParam("password")String password, @RequestParam("type")String type,HttpServletRequest request) 
        {
            String msg = "";
            HttpSession session=request.getSession();
            session.setAttribute("id", username);
             String isValid = authenticateService.findUsss(username, password,type);
            
            
            log.info("Is user valid?= " + isValid);
            
            System.out.println("In the controller..");
            if(isValid!="null") {
                msg = "Welcome " + isValid + "!";
                if (session.getAttribute("user") == null)
                {
        			session.setAttribute("user", msg);
                }
                List<Course> lstProduct =  authenticateService.fetchCourse();
            	
            	
                return new ModelAndView("result1", "result",lstProduct );
                
            } else {
                msg = "Invalid credentials";
                return new ModelAndView("login1","output",msg);
            }
           
        }
        
        @RequestMapping(value = "/quiz", method = RequestMethod.GET)
        public ModelAndView insertCoure( 
        		@RequestParam("code")String code, 
        		@RequestParam("eid")String eid, 
        		@RequestParam("marks")String marks ) {
        	
        	
        	System.out.println(code);
        	Exam u=new Exam();
        	Date dat=new Date();
        	SimpleDateFormat d1=new SimpleDateFormat("dd-MM-yyyy");
        	String newDate=(d1.format(dat)).toString();
        	System.out.println(newDate);
        	u.setCode(code);
        	u.setEid(eid);
        	u.setMarks(marks);
        	u.setDate(newDate);
        	
            String msg = "";
            boolean isValid = authenticateService.insertResult(u);
            log.info("Is entry valid?= " + isValid);
            
            System.out.println("In the controller..");
            ModelAndView model=new ModelAndView("res");
            if(isValid) {
            	
            		msg = "Marks Added successfully... !";
            		model.addObject("s1",msg);
                    //List<Course> lstProduct =  authenticateService.fetchCourse();
                    //model.addObject("result",lstProduct);
            		return model;
            } 
            else {
            	
            		msg = "Invalid credentials ... please try again";
            		model.addObject("s2",msg);
                    //List<Course> lstProduct =  authenticateService.fetchCourse();
                    //model.addObject("result",lstProduct);
            		return model;
            }
 
        }

        
        @RequestMapping(value = "/completed", method = RequestMethod.GET)
        public ModelAndView back(@RequestParam("c")String c) {
            ModelAndView model=new ModelAndView("test1");
            System.out.println("in back Controller");
                List<Result> courses =  authenticateService.fetchCourses(c);
                model.addObject("result1",courses);
        		return model;

        }
       
        @RequestMapping("/back")  
        public ModelAndView back()
        {  
        	ModelAndView model=new ModelAndView("result");
       
                List<Course> lstProduct =  authenticateService.fetchCourse();
                model.addObject("result1",lstProduct);
        		return model;  
        }
        
        @RequestMapping(value="/report",method=RequestMethod.GET)  
        public ModelAndView report(@RequestParam("code")String code) {
            ModelAndView model=new ModelAndView("report");
            System.out.println("in report Controller");
                int courseReport =  authenticateService.fetchReport(code);
                model.addObject("result",courseReport);
        		return model;

        }
       
        
     
}